pkginfo README
==============

This package provides an API for querying the metadata written by
distutils into the ``PKG-INFO`` directory of a source distriubtion (an
``sdist``).

Please see ``docs/index.rst`` for detailed documentation.
