from setuptools import setup

setup(
    name='mypackage',
    version='0.1',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Console (Text Based)',
    ],
)
