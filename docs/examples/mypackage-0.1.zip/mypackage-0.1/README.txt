mypackage README
================

Dummy package for testing ``pkginfo``.
